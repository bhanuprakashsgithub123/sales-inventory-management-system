from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.models.product import Product
from app.models.customer import Customer
from app.models.order import Order, OrderStatus
from app.models.user import User
from app.schemas.dashboard import DashboardResponse, DashboardStats, RecentOrder, LowStockProduct
from app.api.deps import get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/", response_model=DashboardResponse)
def get_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    total_products = db.query(func.count(Product.id)).filter(Product.is_active == True).scalar() or 0
    total_customers = db.query(func.count(Customer.id)).filter(Customer.is_active == True).scalar() or 0
    total_orders = db.query(func.count(Order.id)).scalar() or 0
    pending_approvals = db.query(func.count(Order.id)).filter(
        Order.status == OrderStatus.PENDING_APPROVAL
    ).scalar() or 0
    completed_orders = db.query(func.count(Order.id)).filter(
        Order.status == OrderStatus.COMPLETED
    ).scalar() or 0
    total_sales = db.query(func.coalesce(func.sum(Order.total_amount), 0)).filter(
        Order.status == OrderStatus.COMPLETED
    ).scalar() or 0.0
    low_stock_count = db.query(func.count(Product.id)).filter(
        Product.is_active == True,
        Product.stock_quantity <= Product.low_stock_threshold,
    ).scalar() or 0

    stats = DashboardStats(
        total_products=total_products,
        total_customers=total_customers,
        total_orders=total_orders,
        pending_approvals=pending_approvals,
        completed_orders=completed_orders,
        total_sales=float(total_sales),
        low_stock_products=low_stock_count,
    )

    recent = (
        db.query(Order)
        .order_by(Order.created_at.desc())
        .limit(5)
        .all()
    )
    recent_orders = []
    for o in recent:
        recent_orders.append(RecentOrder(
            id=o.id,
            order_number=o.order_number,
            customer_name=o.customer.name if o.customer else "N/A",
            total_amount=o.total_amount,
            status=o.status.value,
            created_at=o.created_at.isoformat() if o.created_at else "",
        ))

    low_stock_products = (
        db.query(Product)
        .filter(
            Product.is_active == True,
            Product.stock_quantity <= Product.low_stock_threshold,
        )
        .limit(10)
        .all()
    )
    low_stock = [
        LowStockProduct(
            id=p.id,
            name=p.name,
            sku=p.sku,
            stock_quantity=p.stock_quantity,
            low_stock_threshold=p.low_stock_threshold,
        )
        for p in low_stock_products
    ]

    return DashboardResponse(stats=stats, recent_orders=recent_orders, low_stock=low_stock)
