from typing import List
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func
from app.core.database import get_db
from app.core.config import settings
from app.models.order import Order, OrderItem, OrderStatus
from app.models.product import Product
from app.models.customer import Customer
from app.models.user import User, UserRole
from app.schemas.order import (
    OrderCreate, OrderOut, OrderItemOut, OrderApproval, OrderStatus as SchemaOrderStatus
)
from app.api.deps import get_current_user, get_current_manager
from app.utils.email import send_approval_request_email, send_order_decision_email

router = APIRouter(prefix="/orders", tags=["Orders"])


def generate_order_number(db: Session) -> str:
    count = db.query(func.count(Order.id)).scalar() or 0
    return f"ORD-{datetime.now().strftime('%Y%m%d')}-{count + 1:04d}"


def build_order_out(order: Order) -> OrderOut:
    items = []
    for item in order.items:
        items.append(OrderItemOut(
            id=item.id,
            product_id=item.product_id,
            product_name=item.product.name if item.product else None,
            quantity=item.quantity,
            unit_price=item.unit_price,
            subtotal=item.subtotal,
        ))
    return OrderOut(
        id=order.id,
        order_number=order.order_number,
        customer_id=order.customer_id,
        customer_name=order.customer.name if order.customer else None,
        created_by=order.created_by,
        creator_name=order.creator.full_name if order.creator else None,
        approved_by=order.approved_by,
        approver_name=order.approver.full_name if order.approver else None,
        status=order.status,
        total_amount=order.total_amount,
        notes=order.notes,
        rejection_reason=order.rejection_reason,
        created_at=order.created_at,
        approved_at=order.approved_at,
        items=items,
    )


@router.get("/", response_model=List[OrderOut])
def list_orders(
    skip: int = 0,
    limit: int = 50,
    status_filter: SchemaOrderStatus = Query(None, alias="status"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Order).options(
        joinedload(Order.customer),
        joinedload(Order.creator),
        joinedload(Order.approver),
        joinedload(Order.items).joinedload(OrderItem.product),
    )
    if status_filter:
        query = query.filter(Order.status == status_filter)
    # Managers/Admins see all, users see only their own
    if current_user.role == UserRole.USER:
        query = query.filter(Order.created_by == current_user.id)
    orders = query.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()
    return [build_order_out(o) for o in orders]


@router.post("/", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
async def create_order(
    order_in: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate customer
    customer = db.query(Customer).filter(
        Customer.id == order_in.customer_id, Customer.is_active == True
    ).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found or inactive")

    if not order_in.items:
        raise HTTPException(status_code=400, detail="Order must have at least one item")

    total_amount = 0.0
    order_items_data = []

    # Validate products and stock
    for item in order_in.items:
        product = db.query(Product).filter(
            Product.id == item.product_id, Product.is_active == True
        ).first()
        if not product:
            raise HTTPException(
                status_code=404,
                detail=f"Product ID {item.product_id} not found or inactive",
            )
        if product.stock_quantity < item.quantity:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient stock for '{product.name}'. Available: {product.stock_quantity}, Requested: {item.quantity}",
            )
        subtotal = product.price * item.quantity
        total_amount += subtotal
        order_items_data.append({
            "product": product,
            "quantity": item.quantity,
            "unit_price": product.price,
            "subtotal": subtotal,
        })

    # Determine status based on threshold
    requires_approval = total_amount > settings.APPROVAL_THRESHOLD
    status = OrderStatus.PENDING_APPROVAL if requires_approval else OrderStatus.COMPLETED

    # Create order inside transaction
    try:
        order = Order(
            order_number=generate_order_number(db),
            customer_id=order_in.customer_id,
            created_by=current_user.id,
            status=status,
            total_amount=total_amount,
            notes=order_in.notes,
        )
        db.add(order)
        db.flush()  # get order.id

        for item_data in order_items_data:
            order_item = OrderItem(
                order_id=order.id,
                product_id=item_data["product"].id,
                quantity=item_data["quantity"],
                unit_price=item_data["unit_price"],
                subtotal=item_data["subtotal"],
            )
            db.add(order_item)

            # If no approval needed, deduct stock immediately
            if not requires_approval:
                item_data["product"].stock_quantity -= item_data["quantity"]

        db.commit()
        db.refresh(order)

        # Load relationships
        order = db.query(Order).options(
            joinedload(Order.customer),
            joinedload(Order.creator),
            joinedload(Order.items).joinedload(OrderItem.product),
        ).filter(Order.id == order.id).first()

        # Send approval email if needed
        if requires_approval:
            managers = db.query(User).filter(
                User.role.in_([UserRole.MANAGER, UserRole.ADMIN]),
                User.is_active == True,
            ).all()
            for manager in managers:
                await send_approval_request_email(
                    manager_email=manager.email,
                    order_number=order.order_number,
                    total_amount=order.total_amount,
                    creator_name=current_user.full_name,
                    order_id=order.id,
                )

        return build_order_out(order)

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create order: {str(e)}")


@router.get("/{order_id}", response_model=OrderOut)
def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    order = db.query(Order).options(
        joinedload(Order.customer),
        joinedload(Order.creator),
        joinedload(Order.approver),
        joinedload(Order.items).joinedload(OrderItem.product),
    ).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if current_user.role == UserRole.USER and order.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to view this order")
    return build_order_out(order)


@router.post("/{order_id}/approve", response_model=OrderOut)
async def approve_or_reject_order(
    order_id: int,
    approval: OrderApproval,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_manager),
):
    order = db.query(Order).options(
        joinedload(Order.customer),
        joinedload(Order.creator),
        joinedload(Order.items).joinedload(OrderItem.product),
    ).filter(Order.id == order_id).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.status != OrderStatus.PENDING_APPROVAL:
        raise HTTPException(
            status_code=400,
            detail=f"Order is not pending approval. Current status: {order.status.value}",
        )

    try:
        if approval.action == "approve":
            # Deduct inventory
            for item in order.items:
                product = item.product
                if product.stock_quantity < item.quantity:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Insufficient stock for '{product.name}' at approval time. Available: {product.stock_quantity}",
                    )
                product.stock_quantity -= item.quantity

            order.status = OrderStatus.COMPLETED
            order.approved_by = current_user.id
            order.approved_at = datetime.now(timezone.utc)
            decision = "approved"
        else:
            if not approval.rejection_reason:
                raise HTTPException(status_code=400, detail="Rejection reason is required")
            order.status = OrderStatus.REJECTED
            order.approved_by = current_user.id
            order.approved_at = datetime.now(timezone.utc)
            order.rejection_reason = approval.rejection_reason
            decision = "rejected"

        db.commit()
        db.refresh(order)

        # Notify the creator
        if order.creator and order.creator.email:
            await send_order_decision_email(
                user_email=order.creator.email,
                order_number=order.order_number,
                decision=decision,
                total_amount=order.total_amount,
                rejection_reason=order.rejection_reason,
            )

        # Reload with relationships
        order = db.query(Order).options(
            joinedload(Order.customer),
            joinedload(Order.creator),
            joinedload(Order.approver),
            joinedload(Order.items).joinedload(OrderItem.product),
        ).filter(Order.id == order.id).first()

        return build_order_out(order)

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to process approval: {str(e)}")
