import logging
from typing import Optional
from app.core.config import settings

logger = logging.getLogger(__name__)


async def send_email(
    to_email: str,
    subject: str,
    body: str,
    html_body: Optional[str] = None,
) -> bool:
    """
    Send email. If SMTP is not configured, logs to console (demo mode).
    """
    if not settings.SMTP_HOST or not settings.SMTP_USER:
        logger.info("=" * 60)
        logger.info("📧 EMAIL (Console Mode - SMTP not configured)")
        logger.info(f"To: {to_email}")
        logger.info(f"Subject: {subject}")
        logger.info(f"Body:\n{body}")
        logger.info("=" * 60)
        print(f"\n📧 [EMAIL] To: {to_email} | Subject: {subject}\n{body}\n")
        return True

    try:
        import aiosmtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        message = MIMEMultipart("alternative")
        message["From"] = settings.SMTP_FROM
        message["To"] = to_email
        message["Subject"] = subject

        message.attach(MIMEText(body, "plain"))
        if html_body:
            message.attach(MIMEText(html_body, "html"))

        await aiosmtplib.send(
            message,
            hostname=settings.SMTP_HOST,
            port=settings.SMTP_PORT,
            username=settings.SMTP_USER,
            password=settings.SMTP_PASSWORD,
            start_tls=settings.SMTP_TLS,
        )
        logger.info(f"Email sent successfully to {to_email}")
        return True
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {e}")
        # Still log for demo
        print(f"\n📧 [EMAIL FAILED - logged] To: {to_email} | Subject: {subject}\n{body}\n")
        return False


async def send_approval_request_email(
    manager_email: str,
    order_number: str,
    total_amount: float,
    creator_name: str,
    order_id: int,
):
    subject = f"[Action Required] Order {order_number} needs approval"
    body = f"""
Hello Manager,

A new sales order requires your approval.

Order Number : {order_number}
Created By   : {creator_name}
Total Amount : ₹{total_amount:,.2f}

Please log in to the system to Approve or Reject this order.

Order ID: {order_id}
Dashboard: {settings.FRONTEND_URL}

Regards,
{settings.APP_NAME}
"""
    await send_email(manager_email, subject, body)


async def send_order_decision_email(
    user_email: str,
    order_number: str,
    decision: str,
    total_amount: float,
    rejection_reason: Optional[str] = None,
):
    subject = f"Order {order_number} has been {decision.upper()}"
    reason_text = f"\nRejection Reason: {rejection_reason}" if rejection_reason else ""
    body = f"""
Hello,

Your sales order has been {decision}.

Order Number : {order_number}
Total Amount : ₹{total_amount:,.2f}
Status       : {decision.upper()}{reason_text}

You can view the order details in the dashboard.

Regards,
{settings.APP_NAME}
"""
    await send_email(user_email, subject, body)
