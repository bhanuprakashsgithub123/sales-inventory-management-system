from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.database import engine, Base, SessionLocal
from app.core.security import get_password_hash
from app.models.user import User, UserRole
from app.models.product import Product
from app.models.customer import Customer
from app.api.v1 import api_router
from app.core.config import settings
import logging

logging.basicConfig(level=logging.INFO)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    description="Sales & Inventory Management System with Approval Workflow",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1")


def seed_data():
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            users = [
                User(
                    email="admin@example.com",
                    full_name="System Admin",
                    hashed_password=get_password_hash("admin123"),
                    role=UserRole.ADMIN,
                ),
                User(
                    email="manager@example.com",
                    full_name="Sales Manager",
                    hashed_password=get_password_hash("manager123"),
                    role=UserRole.MANAGER,
                ),
                User(
                    email="user@example.com",
                    full_name="Sales Executive",
                    hashed_password=get_password_hash("user123"),
                    role=UserRole.USER,
                ),
            ]
            db.add_all(users)
            print("✅ Seeded default users")

        if db.query(Product).count() == 0:
            products = [
                Product(name="Laptop Pro 15", sku="LAP-001", description="High-performance laptop", price=85000, stock_quantity=25, low_stock_threshold=5),
                Product(name="Wireless Mouse", sku="MOU-001", description="Ergonomic wireless mouse", price=1200, stock_quantity=150, low_stock_threshold=20),
                Product(name="Mechanical Keyboard", sku="KEY-001", description="RGB mechanical keyboard", price=4500, stock_quantity=80, low_stock_threshold=10),
                Product(name="USB-C Hub", sku="HUB-001", description="7-in-1 USB-C hub", price=2800, stock_quantity=60, low_stock_threshold=15),
                Product(name="Monitor 27inch", sku="MON-001", description="4K IPS Monitor", price=32000, stock_quantity=18, low_stock_threshold=5),
                Product(name="Webcam HD", sku="CAM-001", description="1080p webcam", price=3500, stock_quantity=40, low_stock_threshold=8),
            ]
            db.add_all(products)
            print("✅ Seeded sample products")

        if db.query(Customer).count() == 0:
            customers = [
                Customer(name="Acme Corp", email="contact@acme.com", phone="+91-9876543210", address="Mumbai, India"),
                Customer(name="TechStart Pvt Ltd", email="info@techstart.in", phone="+91-9123456780", address="Bangalore, India"),
                Customer(name="Global Traders", email="sales@globaltraders.com", phone="+91-9988776655", address="Delhi, India"),
                Customer(name="Retail Hub", email="orders@retailhub.co", phone="+91-9876501234", address="Hyderabad, India"),
            ]
            db.add_all(customers)
            print("✅ Seeded sample customers")

        db.commit()
    except Exception as e:
        print(f"Seed error: {e}")
        db.rollback()
    finally:
        db.close()


@app.on_event("startup")
def on_startup():
    seed_data()


@app.get("/")
def root():
    return {
        "message": f"Welcome to {settings.APP_NAME}",
        "docs": "/docs",
        "version": "1.0.0",
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
