from pydantic import BaseModel
from typing import List, Optional


class DashboardStats(BaseModel):
    total_products: int
    total_customers: int
    total_orders: int
    pending_approvals: int
    completed_orders: int
    total_sales: float
    low_stock_products: int


class RecentOrder(BaseModel):
    id: int
    order_number: str
    customer_name: str
    total_amount: float
    status: str
    created_at: str


class LowStockProduct(BaseModel):
    id: int
    name: str
    sku: str
    stock_quantity: int
    low_stock_threshold: int


class DashboardResponse(BaseModel):
    stats: DashboardStats
    recent_orders: List[RecentOrder]
    low_stock: List[LowStockProduct]
