export type UserRole = 'user' | 'manager' | 'admin';

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: UserRole;
  is_active: boolean;
  created_at: string;
}

export interface Product {
  id: number;
  name: string;
  sku: string;
  description?: string;
  price: number;
  stock_quantity: number;
  low_stock_threshold: number;
  is_active: boolean;
  created_at: string;
}

export interface Customer {
  id: number;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  is_active: boolean;
  created_at: string;
}

export type OrderStatus = 'draft' | 'pending_approval' | 'approved' | 'rejected' | 'completed' | 'cancelled';

export interface OrderItem {
  id: number;
  product_id: number;
  product_name?: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
}

export interface Order {
  id: number;
  order_number: string;
  customer_id: number;
  customer_name?: string;
  created_by: number;
  creator_name?: string;
  approved_by?: number;
  approver_name?: string;
  status: OrderStatus;
  total_amount: number;
  notes?: string;
  rejection_reason?: string;
  created_at: string;
  approved_at?: string;
  items: OrderItem[];
}

export interface DashboardStats {
  total_products: number;
  total_customers: number;
  total_orders: number;
  pending_approvals: number;
  completed_orders: number;
  total_sales: number;
  low_stock_products: number;
}

export interface DashboardData {
  stats: DashboardStats;
  recent_orders: {
    id: number;
    order_number: string;
    customer_name: string;
    total_amount: number;
    status: string;
    created_at: string;
  }[];
  low_stock: {
    id: number;
    name: string;
    sku: string;
    stock_quantity: number;
    low_stock_threshold: number;
  }[];
}
