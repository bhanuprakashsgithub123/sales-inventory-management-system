import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { DashboardData } from '../types';
import {
  Package,
  Users,
  ShoppingCart,
  Clock,
  CheckCircle,
  IndianRupee,
  AlertTriangle,
} from 'lucide-react';

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard/')
      .then((res) => setData(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!data) return <div className="text-center text-slate-500">Failed to load dashboard</div>;

  const { stats, recent_orders, low_stock } = data;

  const cards = [
    { label: 'Total Products', value: stats.total_products, icon: Package, color: 'bg-blue-500' },
    { label: 'Customers', value: stats.total_customers, icon: Users, color: 'bg-emerald-500' },
    { label: 'Total Orders', value: stats.total_orders, icon: ShoppingCart, color: 'bg-violet-500' },
    { label: 'Pending Approvals', value: stats.pending_approvals, icon: Clock, color: 'bg-amber-500' },
    { label: 'Completed Orders', value: stats.completed_orders, icon: CheckCircle, color: 'bg-green-500' },
    { label: 'Total Sales', value: `₹${stats.total_sales.toLocaleString('en-IN')}`, icon: IndianRupee, color: 'bg-indigo-500' },
  ];

  const statusColor = (s: string) => {
    const map: Record<string, string> = {
      completed: 'bg-green-100 text-green-800',
      pending_approval: 'bg-amber-100 text-amber-800',
      rejected: 'bg-red-100 text-red-800',
      draft: 'bg-slate-100 text-slate-800',
    };
    return map[s] || 'bg-slate-100 text-slate-800';
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
        <Link
          to="/orders/new"
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
        >
          + New Order
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((c) => (
          <div key={c.label} className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4 shadow-sm">
            <div className={`${c.color} p-3 rounded-lg text-white`}>
              <c.icon size={22} />
            </div>
            <div>
              <p className="text-sm text-slate-500">{c.label}</p>
              <p className="text-xl font-bold text-slate-800">{c.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
          <div className="px-5 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-semibold text-slate-800">Recent Orders</h3>
            <Link to="/orders" className="text-sm text-blue-600 hover:underline">View all</Link>
          </div>
          <div className="divide-y divide-slate-100">
            {recent_orders.length === 0 ? (
              <p className="p-5 text-slate-500 text-sm">No orders yet</p>
            ) : (
              recent_orders.map((o) => (
                <Link
                  key={o.id}
                  to={`/orders/${o.id}`}
                  className="flex items-center justify-between px-5 py-3 hover:bg-slate-50 transition"
                >
                  <div>
                    <p className="font-medium text-slate-800 text-sm">{o.order_number}</p>
                    <p className="text-xs text-slate-500">{o.customer_name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">₹{o.total_amount.toLocaleString('en-IN')}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(o.status)}`}>
                      {o.status.replace('_', ' ')}
                    </span>
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>

        {/* Low Stock */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
            <AlertTriangle size={18} className="text-amber-500" />
            <h3 className="font-semibold text-slate-800">Low Stock Alerts</h3>
            <span className="ml-auto text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
              {stats.low_stock_products}
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {low_stock.length === 0 ? (
              <p className="p-5 text-slate-500 text-sm">All products have healthy stock</p>
            ) : (
              low_stock.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-5 py-3">
                  <div>
                    <p className="font-medium text-slate-800 text-sm">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.sku}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-red-600">{p.stock_quantity} left</p>
                    <p className="text-xs text-slate-400">Threshold: {p.low_stock_threshold}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
