import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { Product, Customer } from '../types';
import { Plus, Trash2 } from 'lucide-react';

interface LineItem {
  product_id: number;
  quantity: number;
  product?: Product;
}

export default function CreateOrder() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<LineItem[]>([{ product_id: 0, quantity: 1 }]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      api.get('/customers/'),
      api.get('/products/'),
    ]).then(([cRes, pRes]) => {
      setCustomers(cRes.data);
      setProducts(pRes.data);
    });
  }, []);

  const updateItem = (index: number, field: 'product_id' | 'quantity', value: number) => {
    const next = [...items];
    next[index] = { ...next[index], [field]: value };
    if (field === 'product_id') {
      next[index].product = products.find((p) => p.id === value);
    }
    setItems(next);
  };

  const addItem = () => setItems([...items, { product_id: 0, quantity: 1 }]);
  const removeItem = (index: number) => {
    if (items.length === 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  const total = items.reduce((sum, item) => {
    const p = products.find((pr) => pr.id === item.product_id);
    return sum + (p ? p.price * item.quantity : 0);
  }, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!customerId) {
      setError('Please select a customer');
      return;
    }
    const validItems = items.filter((i) => i.product_id > 0 && i.quantity > 0);
    if (validItems.length === 0) {
      setError('Add at least one product');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/orders/', {
        customer_id: parseInt(customerId),
        items: validItems.map((i) => ({ product_id: i.product_id, quantity: i.quantity })),
        notes: notes || undefined,
      });
      navigate(`/orders/${res.data.id}`);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Create Sales Order</h2>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">{error}</div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Customer *</label>
          <select
            required
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
            className="w-full px-3 py-2.5 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select customer</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-slate-700">Order Items *</label>
            <button type="button" onClick={addItem} className="text-sm text-blue-600 flex items-center gap-1 hover:underline">
              <Plus size={14} /> Add Item
            </button>
          </div>
          <div className="space-y-3">
            {items.map((item, idx) => {
              const product = products.find((p) => p.id === item.product_id);
              return (
                <div key={idx} className="flex gap-3 items-start">
                  <select
                    required
                    value={item.product_id || ''}
                    onChange={(e) => updateItem(idx, 'product_id', parseInt(e.target.value))}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  >
                    <option value="">Select product</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} (₹{p.price.toLocaleString('en-IN')} | Stock: {p.stock_quantity})
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={1}
                    max={product?.stock_quantity || 999}
                    value={item.quantity}
                    onChange={(e) => updateItem(idx, 'quantity', parseInt(e.target.value) || 1)}
                    className="w-24 px-3 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                  <div className="w-28 text-right text-sm font-medium text-slate-700 pt-2">
                    {product ? `₹${(product.price * item.quantity).toLocaleString('en-IN')}` : '—'}
                  </div>
                  <button type="button" onClick={() => removeItem(idx)} className="text-red-400 hover:text-red-600 pt-2">
                    <Trash2 size={16} />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <div>
            <p className="text-sm text-slate-500">Order Total</p>
            <p className="text-2xl font-bold text-slate-800">₹{total.toLocaleString('en-IN')}</p>
            {total > 50000 && (
              <p className="text-xs text-amber-600 mt-1">⚠ This order requires manager approval</p>
            )}
          </div>
          <div className="flex gap-3">
            <button type="button" onClick={() => navigate('/orders')} className="px-5 py-2.5 border rounded-lg text-slate-600 hover:bg-slate-50">
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium"
            >
              {loading ? 'Creating...' : 'Create Order'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
