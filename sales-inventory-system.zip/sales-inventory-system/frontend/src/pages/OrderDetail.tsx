import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { Order } from '../types';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, Check, X } from 'lucide-react';

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showReject, setShowReject] = useState(false);

  const load = () => {
    setLoading(true);
    api.get(`/orders/${id}`)
      .then((res) => setOrder(res.data))
      .catch(() => navigate('/orders'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [id]);

  const handleApprove = async () => {
    if (!confirm('Approve this order and update inventory?')) return;
    setActionLoading(true);
    try {
      await api.post(`/orders/${id}/approve`, { action: 'approve' });
      load();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Approval failed');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      alert('Please provide a rejection reason');
      return;
    }
    setActionLoading(true);
    try {
      await api.post(`/orders/${id}/approve`, {
        action: 'reject',
        rejection_reason: rejectionReason,
      });
      setShowReject(false);
      load();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Rejection failed');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading || !order) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const statusColor: Record<string, string> = {
    completed: 'bg-green-100 text-green-800',
    pending_approval: 'bg-amber-100 text-amber-800',
    rejected: 'bg-red-100 text-red-800',
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Link to="/orders" className="text-slate-500 hover:text-slate-800">
          <ArrowLeft size={20} />
        </Link>
        <h2 className="text-2xl font-bold text-slate-800">{order.order_number}</h2>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColor[order.status] || 'bg-slate-100'}`}>
          {order.status.replace('_', ' ')}
        </span>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-slate-500">Customer</p>
            <p className="font-medium text-slate-800">{order.customer_name}</p>
          </div>
          <div>
            <p className="text-slate-500">Created By</p>
            <p className="font-medium text-slate-800">{order.creator_name}</p>
          </div>
          <div>
            <p className="text-slate-500">Created At</p>
            <p className="font-medium text-slate-800">{new Date(order.created_at).toLocaleString()}</p>
          </div>
          {order.approver_name && (
            <div>
              <p className="text-slate-500">Processed By</p>
              <p className="font-medium text-slate-800">{order.approver_name}</p>
            </div>
          )}
          {order.notes && (
            <div className="col-span-2">
              <p className="text-slate-500">Notes</p>
              <p className="text-slate-800">{order.notes}</p>
            </div>
          )}
          {order.rejection_reason && (
            <div className="col-span-2">
              <p className="text-slate-500">Rejection Reason</p>
              <p className="text-red-600">{order.rejection_reason}</p>
            </div>
          )}
        </div>

        <div className="border-t border-slate-100 pt-4">
          <h3 className="font-semibold text-slate-800 mb-3">Items</h3>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-slate-500 border-b">
                <th className="text-left py-2">Product</th>
                <th className="text-right py-2">Qty</th>
                <th className="text-right py-2">Unit Price</th>
                <th className="text-right py-2">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item) => (
                <tr key={item.id} className="border-b border-slate-50">
                  <td className="py-2.5 font-medium">{item.product_name}</td>
                  <td className="py-2.5 text-right">{item.quantity}</td>
                  <td className="py-2.5 text-right">₹{item.unit_price.toLocaleString('en-IN')}</td>
                  <td className="py-2.5 text-right font-medium">₹{item.subtotal.toLocaleString('en-IN')}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} className="pt-3 text-right font-semibold text-slate-700">Total</td>
                <td className="pt-3 text-right text-lg font-bold text-slate-800">
                  ₹{order.total_amount.toLocaleString('en-IN')}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {isManager && order.status === 'pending_approval' && (
          <div className="border-t border-slate-100 pt-5 flex gap-3">
            <button
              onClick={handleApprove}
              disabled={actionLoading}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg font-medium disabled:opacity-50"
            >
              <Check size={18} /> Approve & Complete
            </button>
            <button
              onClick={() => setShowReject(true)}
              disabled={actionLoading}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg font-medium disabled:opacity-50"
            >
              <X size={18} /> Reject
            </button>
          </div>
        )}
      </div>

      {showReject && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
            <h3 className="text-lg font-semibold mb-3">Reject Order</h3>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Reason for rejection..."
              rows={3}
              className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-red-500 mb-4"
            />
            <div className="flex gap-3">
              <button onClick={() => setShowReject(false)} className="flex-1 py-2 border rounded-lg">Cancel</button>
              <button onClick={handleReject} disabled={actionLoading} className="flex-1 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50">
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
