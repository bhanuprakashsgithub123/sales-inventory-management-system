# Sales & Inventory Management System

A full-stack web application for managing products, customers, sales orders, inventory, and an approval workflow for high-value orders.

**Tech Stack:** React.js · FastAPI · Python · MySQL

---

## Features

- **Authentication** – JWT-based login with role-based access (User / Manager / Admin)
- **Product Management** – CRUD, stock tracking, low-stock alerts
- **Customer Management** – CRUD operations
- **Sales Orders** – Create orders with multiple line items, real-time stock validation
- **Approval Workflow**
  - Orders above ₹50,000 automatically go to `PENDING_APPROVAL`
  - Email notification sent to managers
  - Manager can Approve (inventory deducted) or Reject (with reason)
  - Creator notified by email of the decision
- **Dashboard** – Sales, orders, pending approvals, low stock overview
- **Transaction Safety** – Inventory updates happen atomically
- **Clean API Design** – RESTful, validated with Pydantic, documented with Swagger

---

## Quick Start (Recommended – Docker)

### Prerequisites
- Docker & Docker Compose

```bash
# Clone the repository
git clone <your-repo-url>
cd sales-inventory-system

# Start MySQL + Backend
docker-compose up --build -d

# Backend will be available at http://localhost:8000
# API Docs: http://localhost:8000/docs
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at **http://localhost:5173**

---

## Demo Accounts

| Role     | Email                 | Password    |
|----------|-----------------------|-------------|
| Admin    | admin@example.com     | admin123    |
| Manager  | manager@example.com   | manager123  |
| User     | user@example.com      | user123     |

---

## How the Approval Flow Works

1. A **User** creates a sales order.
2. System validates stock availability for every item.
3. If **Total Amount ≤ ₹50,000** → Order is immediately **COMPLETED** and inventory is reduced.
4. If **Total Amount > ₹50,000** → Status becomes `PENDING_APPROVAL` and managers receive an email notification.
5. **Manager** reviews the order:
   - **Approve** → Inventory is deducted, status becomes `COMPLETED`, user receives confirmation email.
   - **Reject** → Status becomes `REJECTED` (with reason), user is notified by email.
6. All inventory changes are performed inside a database transaction.

> Approval threshold is configurable via `APPROVAL_THRESHOLD` environment variable (default: 50000).

---

## Project Structure

```
sales-inventory-system/
├── backend/
│   ├── app/
│   │   ├── api/v1/          # Route handlers
│   │   ├── core/            # Config, security, database
│   │   ├── models/          # SQLAlchemy models
│   │   ├── schemas/         # Pydantic schemas
│   │   ├── utils/           # Email utility
│   │   └── main.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── context/
│   │   ├── services/
│   │   └── types/
│   └── package.json
├── docker-compose.yml
└── README.md
```

---

## API Endpoints (Overview)

| Method | Endpoint                        | Description                  | Auth |
|--------|---------------------------------|------------------------------|------|
| POST   | `/api/v1/auth/login`            | Login                        | No   |
| POST   | `/api/v1/auth/register`         | Register                     | No   |
| GET    | `/api/v1/auth/me`               | Current user                 | Yes  |
| GET    | `/api/v1/products/`             | List products                | Yes  |
| POST   | `/api/v1/products/`             | Create product               | Yes  |
| GET    | `/api/v1/customers/`            | List customers               | Yes  |
| POST   | `/api/v1/orders/`               | Create order                 | Yes  |
| GET    | `/api/v1/orders/`               | List orders                  | Yes  |
| POST   | `/api/v1/orders/{id}/approve`   | Approve / Reject order       | Manager |
| GET    | `/api/v1/dashboard/`            | Dashboard stats              | Yes  |

Full interactive documentation: **http://localhost:8000/docs**

---

## Local Development (without Docker)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Create a MySQL database named sales_inventory
# Then set DATABASE_URL in .env or export it
export DATABASE_URL="mysql+pymysql://root:password@localhost:3306/sales_inventory"
export SECRET_KEY="your-secret-key"

uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

---

## Email Configuration (Optional)

By default the system runs in **console mode** – emails are printed to the terminal (perfect for demos).

To enable real SMTP (e.g. Gmail):

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=your-email@gmail.com
SMTP_TLS=True
```

---

## Key Implementation Highlights

- Clean separation of concerns (models / schemas / routes / services)
- Role-based access control
- Atomic inventory updates with proper error handling
- Configurable approval threshold
- Soft deletes for products & customers
- Responsive modern UI with Tailwind CSS
- Seed data for instant demo

---

## Author

Developed as part of the Web Developer technical assignment for Bookxpert Pvt Ltd.

---

## License

This project is for evaluation purposes.
